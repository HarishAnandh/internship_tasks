package com.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
    public static void main(String[] args) {
        // 1. Create SessionFactory
        SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Student.class).buildSessionFactory();
        
        Session session = factory.openSession();
        Transaction tx = null;

        try {
            // ==========================================
            // 1. CREATE (Insert a new student)
            // ==========================================
            tx = session.beginTransaction();
            Student student = new Student(1, "Rahul", 20);
            session.persist(student); // Saves the student
            tx.commit();
            System.out.println("--> CREATE: Student saved successfully!");

            // ==========================================
            // 2. READ (Fetch the student from database)
            // ==========================================
            session.clear(); // Clear cache to force database read
            Student retrievedStudent = session.find(Student.class, 1);
            System.out.println("--> READ: Found Student -> Name: " + retrievedStudent.getName() + ", Age: " + retrievedStudent.getAge());

            // ==========================================
            // 3. UPDATE (Modify student's age)
            // ==========================================
            tx = session.beginTransaction();
            Student studentToUpdate = session.find(Student.class, 1);
            studentToUpdate.setAge(21); // Update age from 20 to 21
            session.merge(studentToUpdate); // Updates the record in MySQL
            tx.commit();
            System.out.println("--> UPDATE: Student age updated to 21!");

            // Verify update by reading again
            Student updatedStudent = session.find(Student.class, 1);
            System.out.println("--> READ AFTER UPDATE: Age is now " + updatedStudent.getAge());

            // ==========================================
            // 4. DELETE (Remove student from database)
            // ==========================================
            tx = session.beginTransaction();
            Student studentToDelete = session.find(Student.class, 1);
            if (studentToDelete != null) {
                session.remove(studentToDelete); // Deletes the record
                System.out.println("--> DELETE: Student removed from database.");
            }
            tx.commit();

        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
            factory.close();
        }
    }
}