package com.example;

import jakarta.persistence.*;

@Entity
@Table(name = "contract_employee")
@PrimaryKeyJoinColumn(name = "employee_id")
public class ContractEmployee extends Employee {

    private double bonus;
    private String agencyName;

    public ContractEmployee() {}

    public ContractEmployee(String name, String email, double salary, Department department, double bonus, String agencyName) {
        super(name, email, salary, department);
        this.bonus = bonus;
        this.agencyName = agencyName;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    public String getAgencyName() {
        return agencyName;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }
}