package com.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();

        // 1. Create and persist 5 Departments
        Department hr = new Department("HR");
        Department it = new Department("IT");
        Department finance = new Department("Finance");
        Department marketing = new Department("Marketing");
        Department sales = new Department("Sales");

        session.persist(hr);
        session.persist(it);
        session.persist(finance);
        session.persist(marketing);
        session.persist(sales);

        // 2. Create and persist Employees passing Department directly in constructor
        PermanentEmployee e1 = new PermanentEmployee("Alice", "alice@test.com", 75000.0, it, 10000.0, "Senior Developer");
        ContractEmployee e2 = new ContractEmployee("Bob", "bob@test.com", 45000.0, it, 3000.0, "TechStaffing Inc");
        PermanentEmployee e3 = new PermanentEmployee("Charlie", "charlie@test.com", 82000.0, hr, 12000.0, "HR Director");
        ContractEmployee e4 = new ContractEmployee("Diana", "diana@test.com", 50000.0, finance, 4000.0, "GlobalAgencies");
        PermanentEmployee e5 = new PermanentEmployee("Eve", "eve@test.com", 68000.0, marketing, 8000.0, "Marketing Lead");

        session.persist(e1);
        session.persist(e2);
        session.persist(e3);
        session.persist(e4);
        session.persist(e5);

        tx.commit();

        System.out.println("\n--- Data Successfully Inserted ---\n");

        // ==================== 6 REQUIRED HQL QUERIES ====================

        // Query 1: Display All Employees
        System.out.println("=== Query 1: Display All Employees ===");
        List<Employee> allEmployees = session.createQuery("FROM Employee", Employee.class).getResultList();
        for (Employee emp : allEmployees) {
            System.out.println("ID: " + emp.getEmployeeId() + " | Name: " + emp.getName() + " | Salary: $" + emp.getSalary() + " | Email: " + emp.getEmail());
        }

        // Query 2: Employee Name & Department Name (using JOIN)
        System.out.println("\n=== Query 2: Employee Name & Department Name (using JOIN) ===");
        List<Object[]> q2Results = session.createQuery("SELECT e.name, d.departmentName FROM Employee e JOIN e.department d", Object[].class).getResultList();
        for (Object[] row : q2Results) {
            System.out.println("Employee Name: " + row[0] + " | Department: " + row[1]);
        }

        // Query 3: Employees of a Given Department
        System.out.println("\n=== Query 3: Employees in 'IT' Department ===");
        List<Employee> itEmployees = session.createQuery("FROM Employee e WHERE e.department.departmentName = :deptName", Employee.class)
                .setParameter("deptName", "IT")
                .getResultList();
        for (Employee emp : itEmployees) {
            System.out.println("Name: " + emp.getName() + " | Dept: " + emp.getDepartment().getDepartmentName());
        }

        // Query 4: Salary Above a Given Amount
        System.out.println("\n=== Query 4: Employees with Salary > 60000 ===");
        List<Employee> highSalaryEmps = session.createQuery("FROM Employee e WHERE e.salary > :minSalary", Employee.class)
                .setParameter("minSalary", 60000.0)
                .getResultList();
        for (Employee emp : highSalaryEmps) {
            System.out.println("Name: " + emp.getName() + " | Salary: $" + emp.getSalary());
        }

        // Query 5: Permanent Employees with Department Details
        System.out.println("\n=== Query 5: Permanent Employees with Department Details ===");
        List<PermanentEmployee> permEmps = session.createQuery("FROM PermanentEmployee p JOIN FETCH p.department", PermanentEmployee.class).getResultList();
        for (PermanentEmployee p : permEmps) {
            System.out.println("ID: " + p.getEmployeeId() + " | Name: " + p.getName() + " | Designation: " + p.getDesignation() + " | Department: " + p.getDepartment().getDepartmentName());
        }

        // Query 6: Java Class Type of Each Employee
        System.out.println("\n=== Query 6: Java Class Type of Each Employee ===");
        List<Object[]> q6Results = session.createQuery("SELECT e.name, TYPE(e) FROM Employee e", Object[].class).getResultList();
        for (Object[] row : q6Results) {
            String name = (String) row[0];
            Class<?> clazz = (Class<?>) row[1];
            System.out.println("Employee Name: " + name + " | Class Type: " + clazz.getSimpleName());
        }

        session.close();
        factory.close();
    }
}