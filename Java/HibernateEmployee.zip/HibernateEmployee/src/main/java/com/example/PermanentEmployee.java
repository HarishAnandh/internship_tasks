package com.example;

import jakarta.persistence.*;

@Entity
@Table(name = "permanent_employee")
@PrimaryKeyJoinColumn(name = "employee_id")
public class PermanentEmployee extends Employee {

    private double bonus;
    private String designation;

    public PermanentEmployee() {}

    public PermanentEmployee(String name, String email, double salary, Department department, double bonus, String designation) {
        super(name, email, salary, department);
        this.bonus = bonus;
        this.designation = designation;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }
}